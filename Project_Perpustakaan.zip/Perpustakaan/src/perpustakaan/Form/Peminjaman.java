package perpustakaan.Form;

import com.toedter.calendar.JDateChooser;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import perpustakaan.CRUD;

/**
 *
 * @author ELING
 */
public class Peminjaman extends javax.swing.JFrame {
CRUD peminjaman = new CRUD();
    String status = "";
    public Peminjaman() {
        initComponents();
        peminjaman.koneksi();
        TampilPeminjaman();
    }
    public void TampilPeminjaman(){
        String namaTable = "peminjaman";
        String daftarField[]  = {
            "id_peminjaman",
            "tanggal_peminjaman",
            "id_buku",
            "nim_mahasiswa",
            "id_pegawai"
        };
        String judulKolom[] = {
            "ID",
            "Tanggal Peminjaman",
            "ID Buku",
            "Nim Mahasiswa",
            "ID Pegawai"
        };
        tablePeminjaman.setModel(peminjaman.TampilData(namaTable, daftarField, judulKolom));
    }
    public void TambahPeminjaman() {
        Date selectedDate = txtTanggal.getDate();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(selectedDate);
        int idBuku = -1;         
        int nimMahasiswa = -1; 
        int idPegawai = -1;
//        Buku
        try {
            String judulBuku = txtBuku.getSelectedItem().toString();
            Buku_1 buku = Buku_1.findByJudulBuku(judulBuku);
            if (buku != null) {
                idBuku = buku.getIdBuku();
            } else {
                idBuku = -1;
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
            return;
        }
//        Mahasiswa
        try {
            String namaMahasiswa = txtMahasiswa.getSelectedItem().toString();
            Mahasiswa_1 mahasiswa = Mahasiswa_1.findByNamaMahasiswa(namaMahasiswa);
            if (mahasiswa != null) {
                nimMahasiswa = mahasiswa.getNimMahasiswa();
            } else {
                nimMahasiswa = -1;
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
            return;
        }
//        Pegawai
        try {
            String namaPegawai = txtPegawai.getSelectedItem().toString();
            Pegawai_1 pegawai = Pegawai_1.findByNamaPegawai(namaPegawai);
            if (pegawai != null) {
                idPegawai = pegawai.getIdPegawai();
            } else {
                idPegawai = -1;
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
            return;
        }
        
        String status = peminjaman.tambah("peminjaman", "id_peminjaman,tanggal_peminjaman,id_buku,nim_mahasiswa,id_pegawai",
                "'" + txtId.getText() + "'," +
                "'" + formattedDate + "'," +
                "'" + idBuku + "'," +
                "'" + nimMahasiswa + "'," +
                "'" + idPegawai + "'"
        );
        JOptionPane.showMessageDialog(null, status);
        TampilPeminjaman();
        kosongkan();
    }
    public void kosongkan(){
        JDateChooser txtTanggal = new JDateChooser();
        txtId.setText("");
        txtTanggal.setDate(new java.util.Date());
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("perpustakaan?zeroDateTimeBehavior=convertToNullPU").createEntityManager();
        buku_1Query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT b FROM Buku_1 b");
        buku_1List = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : buku_1Query.getResultList();
        mahasiswa_1Query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT m FROM Mahasiswa_1 m");
        mahasiswa_1List = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : mahasiswa_1Query.getResultList();
        pegawai_1Query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT p FROM Pegawai_1 p");
        pegawai_1List = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : pegawai_1Query.getResultList();
        jPanel2 = new javax.swing.JPanel();
        btnKembali = new javax.swing.JButton();
        txtTanggal = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablePeminjaman = new javax.swing.JTable();
        txtBuku = new javax.swing.JComboBox<>();
        txtMahasiswa = new javax.swing.JComboBox<>();
        txtPegawai = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnTambah = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(134, 182, 246));

        jPanel2.setBackground(new java.awt.Color(17, 35, 90));

        btnKembali.setText("Kembali");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        tablePeminjaman.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablePeminjaman);

        org.jdesktop.swingbinding.JComboBoxBinding jComboBoxBinding = org.jdesktop.swingbinding.SwingBindings.createJComboBoxBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, buku_1List, txtBuku);
        bindingGroup.addBinding(jComboBoxBinding);

        jComboBoxBinding = org.jdesktop.swingbinding.SwingBindings.createJComboBoxBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, mahasiswa_1List, txtMahasiswa);
        bindingGroup.addBinding(jComboBoxBinding);

        jComboBoxBinding = org.jdesktop.swingbinding.SwingBindings.createJComboBoxBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, pegawai_1List, txtPegawai);
        bindingGroup.addBinding(jComboBoxBinding);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tanggal");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Buku");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Mahasiwa");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Pegawai");

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnTambah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnKembali))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtId)
                            .addComponent(txtTanggal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtBuku, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtMahasiswa, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtPegawai, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 601, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(txtTanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jLabel2)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtBuku, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPegawai, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTambah)
                            .addComponent(btnKembali))))
                .addContainerGap(150, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        TambahPeminjaman();
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        this.dispose();
        Menu menu = new Menu();
        menu.setVisible(true);
    }//GEN-LAST:event_btnKembaliActionPerformed
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Peminjaman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnTambah;
    private java.util.List<perpustakaan.Form.Buku_1> buku_1List;
    private javax.persistence.Query buku_1Query;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private java.util.List<perpustakaan.Form.Mahasiswa_1> mahasiswa_1List;
    private javax.persistence.Query mahasiswa_1Query;
    private java.util.List<perpustakaan.Form.Pegawai_1> pegawai_1List;
    private javax.persistence.Query pegawai_1Query;
    private javax.swing.JTable tablePeminjaman;
    private javax.swing.JComboBox<String> txtBuku;
    private javax.swing.JTextField txtId;
    private javax.swing.JComboBox<String> txtMahasiswa;
    private javax.swing.JComboBox<String> txtPegawai;
    private com.toedter.calendar.JDateChooser txtTanggal;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
