package perpustakaan;

import perpustakaan.Form.Login;
public class Perpustakaan {
    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
    
}
